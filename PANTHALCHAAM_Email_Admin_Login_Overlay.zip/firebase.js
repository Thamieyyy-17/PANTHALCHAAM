import { initializeApp, getApps, getApp } from 'firebase/app';
import { getAuth, signInWithEmailAndPassword, signOut } from 'firebase/auth';
import { getFirestore, collection, doc, getDoc, onSnapshot } from 'firebase/firestore';
import { getFunctions, httpsCallable } from 'firebase/functions';
import { getMessaging, getToken, isSupported, onMessage } from 'firebase/messaging';

const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID,
  appId: import.meta.env.VITE_FIREBASE_APP_ID,
};

export const firebaseConfigured = ['apiKey', 'authDomain', 'projectId', 'appId'].every(key => Boolean(firebaseConfig[key]));
export const app = firebaseConfigured ? (getApps().length ? getApp() : initializeApp(firebaseConfig)) : null;
// Let the Firebase SDK choose a supported persistence mechanism for the WebView/browser.
// PANTHALCHAAM business records are stored in Firestore.
export const auth = app ? getAuth(app) : null;
export const db = app ? getFirestore(app) : null;
export const functions = app ? getFunctions(app, 'asia-south1') : null;
let messagingInstance = null;
async function messaging() {
  if (!app || typeof window === 'undefined' || !('serviceWorker' in navigator) || !(await isSupported())) return null;
  if (!messagingInstance) messagingInstance = getMessaging(app);
  return messagingInstance;
}
export async function registerWebPush({ requestPermission = true } = {}) {
  const service = await messaging();
  if (!service || !('Notification' in window)) return null;
  if (Notification.permission === 'default' && requestPermission) await Notification.requestPermission();
  if (Notification.permission !== 'granted') return null;
  const vapidKey = import.meta.env.VITE_FIREBASE_VAPID_KEY;
  if (!vapidKey) throw new Error('Firebase VAPID public key is missing from the build configuration.');
  const registration = await navigator.serviceWorker.register('/firebase-messaging-sw.js');
  return getToken(service, { vapidKey, serviceWorkerRegistration: registration });
}
export async function listenForWebMessages(callback) {
  const service = await messaging();
  return service ? onMessage(service, callback) : () => {};
}
export const call = (name, data) => {
  if (!functions) return Promise.reject(new Error('Firebase is not configured.'));
  return httpsCallable(functions, name)(data).then(result => result.data);
};

const ownerEmail = code => call('ownerLogin', { code }).then(result => result.email);
export async function ownerSignIn(code, password) {
  const email = await ownerEmail(code);
  const credential = await signInWithEmailAndPassword(auth, email, password);
  const token = await credential.user.getIdTokenResult(true);
  if (!token.claims.ownerId) {
    await signOut(auth);
    throw new Error('This account is not enabled as a PANTHALCHAAM owner.');
  }
  return credential.user;
}

export async function isRegisteredAdmin(user) {
  if (!user || !db) return false;
  const adminSnapshot = await getDoc(doc(db, 'admins', user.uid));
  return adminSnapshot.exists() && adminSnapshot.data()?.active === true;
}

// Admin authorization is an explicit Firestore allow-list entry; no bootstrap callable or secret is used.
export async function adminSignIn(email, password) {
  if (!auth || !db) throw new Error('Firebase is not configured.');
  if (!email || !password) throw new Error('Enter your admin email and password.');
  const credential = await signInWithEmailAndPassword(auth, email, password);
  if (!(await isRegisteredAdmin(credential.user))) {
    await signOut(auth);
    throw new Error('This account is not enabled as a PANTHALCHAAM admin. Ask the project administrator to activate its UID in Firestore admins.');
  }
  return credential.user;
}

export async function signOutTurfBook() {
  if (auth) await signOut(auth);
}

export const watchTurfs = (callback, onError) => onSnapshot(collection(db, 'turfs'), snapshot => callback(snapshot.docs.map(document => ({ id: document.id, ...document.data() }))), onError);
export const watchSettings = (callback, onError) => onSnapshot(doc(db, 'settings', 'public'), snapshot => callback(snapshot.exists() ? snapshot.data() : {}), onError);
export { signOut };
